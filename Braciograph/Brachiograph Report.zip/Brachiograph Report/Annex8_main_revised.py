from machine import Pin, PWM, ADC
import math, time

# Constants
ServoFreq = 50 # Hz

# Robot arm dimensions (in mm)
Lab = 155 # shoulder to elbow
Lbc = 155 # elbow to pen

# Shoulder base position (in mm)
ShoulderX = -50
ShoulderY = 139.5

# Servos
pwm_shoulder = PWM(Pin(0))
pwm_shoulder.freq(ServoFreq)
pwm_elbow = PWM(Pin(1))
pwm_elbow.freq(ServoFreq)
pwm_pen = PWM(Pin(2))
pwm_pen.freq(ServoFreq)

# Potentiometers for X and Y control
pot_x = ADC(Pin(26)) # X-axis potentiometer
pot_y = ADC(Pin(27)) # Y-axis potentiometer

# Button for pen toggle
pen_button = Pin(16, Pin.IN, Pin.PULL_DOWN)

# Pen state
pen_is_down = False
pen_moving = False
pen_move_start_time = 0
pen_up_angle = 0      # Angle when pen is lifted
pen_down_angle = 30    # Angle when pen is on paper

shoulder_offset = 56
elbow_offset = 12

def translate(angle):
    """
    Converts an angle in degrees to the corresponding input
    for the duty_u16 method of the servo class
    """
    MIN = 1638  # 0 degrees
    MAX = 8192  # 180 degrees
    DEG = (MAX - MIN) / 180  # value per degree

    # clamp angle to be between 0 and 180
    angle = max(0, min(180, angle))

    return int(angle * DEG + MIN)

def set_servo_deg(pwm, angle_deg):
    """Give the servo (pwm) an angle (angle_deg) to go to"""
    pwm.duty_u16(translate(angle_deg))

def send_angle(shoulder_angle, elbow_angle):    
    # Send to servos
    set_servo_deg(pwm_shoulder, shoulder_angle)
    set_servo_deg(pwm_elbow, elbow_angle)

def inverse_kinematics(Cx, Cy):
    """
    Given the desired coordinates, this function allows us to do the math to retrieve
    alpha and beta. All the equations were derived by Anthony.
    """
    dx = ShoulderX - Cx
    dy = ShoulderY - Cy
    AC = math.sqrt(dx**2 + dy**2)
    delta = math.asin(abs(dy)/AC)
    delta = math.degrees(delta)
    angle_BAC = math.degrees(math.acos((Lbc**2 + AC**2 - Lab**2) / (2 * Lbc * AC)))
    angle_ABC = math.degrees(math.acos((Lab**2 + Lbc**2 - AC**2) / (2 * Lab * Lbc)))
    if Cy > ShoulderY:
        delta = -delta
    beta = 180 - angle_ABC
    alpha = 90 - angle_BAC - delta

    shoulder_angle = alpha + shoulder_offset
    elbow_angle = 180 - elbow_offset - beta
    return shoulder_angle, elbow_angle

def move_to(x, y):
    """
    Move the pen to position (x, y) in mm
    """
    servoA, servoB = inverse_kinematics(x, y) # Calculate servo angles
    
    send_angle(servoA, servoB) # Send angles to servos
    
    time.sleep_ms(50)

def read_potentiometers():
    """
    Read potentiometer values and map to X, Y coordinates
    
    Returns:
        tuple: (x, y) coordinates in mm
    """
    # Read raw ADC values (0-65535 for 16-bit ADC)
    raw_x = pot_x.read_u16()
    raw_y = pot_y.read_u16()
    
    # Map to paper coordinates
    # Apply some smoothing by averaging with current position
    x = (raw_x / 65535) * 215
    y = (raw_y / 65535) * 279
    
    return x, y

def toggle_pen():
    global pen_is_down, pen_moving, pen_move_start_time
    """Toggle pen between up and down states"""
    if pen_is_down or pen_moving:
        set_servo_deg(pwm_pen, pen_up_angle)
        pen_is_down = False
        pen_moving = True
        pen_move_start_time = time.ticks_ms()
        print("Pen UP")
    else:
        if not pen_is_down:
            set_servo_deg(pwm_pen, pen_down_angle)
            pen_is_down = True
            pen_moving = True
            pen_move_start_time = time.ticks_ms()
            print("Pen DOWN")

def update_pen_state():
    """
    Update pen movement state - check if pen has finished moving
    This prevents continuous servo strain once pen reaches target
    """
    global pen_moving
    
    if pen_moving:
        elapsed = time.ticks_diff(time.ticks_ms(), pen_move_start_time)
        if elapsed >= 300: # 300ms to complete movement
            pen_moving = False

def main():
    """
    Main is our loop that keeps the program running. Handles pen and servos.
    """
    while True:

        current_state = pen_button.value()
    
        if prev_state == 0 and current_state == 1:
            update_pen_state()
            toggle_pen()
            time.sleep_ms(200)
        
        prev_state = current_state

        x,y = read_potentiometers()

        move_to(x, y)

        time.sleep_us(50)

def calibrate_jig(jig_id):
    """
    This function reads our calibrate file and updates the global 
    constants regarding the servo adjustments.
    """
    global shoulder_offset, elbow_offset

    filename = f"calibration_data_{jig_id}.txt"
    try:
        with open(filename, 'r') as calibrated_file:
            for line in calibrated_file:
                line = line.strip()
                
                # Skip empty lines and comments
                if not line or line.startswith('#'):
                    continue
                
                # Check for section headers
                if line == '[S]' and ',' in line:
                    parts = line.split(',')
                    shoulder_offset = float(parts[1])
                    continue
                elif line == '[E]' and ',' in line:
                    parts = line.split(',')
                    elbow_offset = float(parts[1])
        
    except OSError:
        print(f"Warning: Could not open calibration file {filename}")
        print("Using default constants (no error compensation)")
    
    return

if __name__ == "__main__":    
    try:
        calibrate_jig(input("Enter your test jig ID: ").strip())
        main()
    except:
        print("\nThe porgram has been forcefully stopped")